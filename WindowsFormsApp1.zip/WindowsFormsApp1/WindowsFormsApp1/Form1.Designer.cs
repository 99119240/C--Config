﻿
namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Switch1 = new Guna.UI2.WinForms.Guna2ToggleSwitch();
            this.Switch2 = new Guna.UI2.WinForms.Guna2ToggleSwitch();
            this.Switch3 = new Guna.UI2.WinForms.Guna2ToggleSwitch();
            this.ConfigListBoxCGF = new System.Windows.Forms.ListBox();
            this.LoadConfigBTN = new Guna.UI2.WinForms.Guna2Button();
            this.SaveConfigBTN = new Guna.UI2.WinForms.Guna2Button();
            this.SuspendLayout();
            // 
            // Switch1
            // 
            this.Switch1.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Switch1.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Switch1.CheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.Switch1.CheckedState.InnerColor = System.Drawing.Color.White;
            this.Switch1.Location = new System.Drawing.Point(350, 154);
            this.Switch1.Name = "Switch1";
            this.Switch1.Size = new System.Drawing.Size(35, 20);
            this.Switch1.TabIndex = 0;
            this.Switch1.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.Switch1.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.Switch1.UncheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.Switch1.UncheckedState.InnerColor = System.Drawing.Color.White;
            this.Switch1.CheckedChanged += new System.EventHandler(this.Switch1_CheckedChanged);
            // 
            // Switch2
            // 
            this.Switch2.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Switch2.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Switch2.CheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.Switch2.CheckedState.InnerColor = System.Drawing.Color.White;
            this.Switch2.Location = new System.Drawing.Point(350, 180);
            this.Switch2.Name = "Switch2";
            this.Switch2.Size = new System.Drawing.Size(35, 20);
            this.Switch2.TabIndex = 1;
            this.Switch2.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.Switch2.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.Switch2.UncheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.Switch2.UncheckedState.InnerColor = System.Drawing.Color.White;
            this.Switch2.CheckedChanged += new System.EventHandler(this.Switch2_CheckedChanged);
            // 
            // Switch3
            // 
            this.Switch3.Checked = true;
            this.Switch3.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Switch3.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Switch3.CheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.Switch3.CheckedState.InnerColor = System.Drawing.Color.White;
            this.Switch3.Location = new System.Drawing.Point(350, 206);
            this.Switch3.Name = "Switch3";
            this.Switch3.Size = new System.Drawing.Size(35, 20);
            this.Switch3.TabIndex = 2;
            this.Switch3.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.Switch3.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.Switch3.UncheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.Switch3.UncheckedState.InnerColor = System.Drawing.Color.White;
            this.Switch3.CheckedChanged += new System.EventHandler(this.Switch3_CheckedChanged);
            // 
            // ConfigListBoxCGF
            // 
            this.ConfigListBoxCGF.FormattingEnabled = true;
            this.ConfigListBoxCGF.Items.AddRange(new object[] {
            "Config1",
            "Config2",
            "Config3"});
            this.ConfigListBoxCGF.Location = new System.Drawing.Point(350, 53);
            this.ConfigListBoxCGF.Name = "ConfigListBoxCGF";
            this.ConfigListBoxCGF.Size = new System.Drawing.Size(120, 95);
            this.ConfigListBoxCGF.TabIndex = 4;
            this.ConfigListBoxCGF.SelectedIndexChanged += new System.EventHandler(this.ConfigListBoxCGF_SelectedIndexChanged);
            // 
            // LoadConfigBTN
            // 
            this.LoadConfigBTN.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.LoadConfigBTN.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.LoadConfigBTN.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.LoadConfigBTN.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.LoadConfigBTN.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.LoadConfigBTN.ForeColor = System.Drawing.Color.White;
            this.LoadConfigBTN.Location = new System.Drawing.Point(476, 53);
            this.LoadConfigBTN.Name = "LoadConfigBTN";
            this.LoadConfigBTN.Size = new System.Drawing.Size(117, 26);
            this.LoadConfigBTN.TabIndex = 5;
            this.LoadConfigBTN.Text = "Load";
            this.LoadConfigBTN.Click += new System.EventHandler(this.LoadConfigBTN_Click);
            // 
            // SaveConfigBTN
            // 
            this.SaveConfigBTN.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.SaveConfigBTN.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.SaveConfigBTN.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.SaveConfigBTN.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.SaveConfigBTN.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.SaveConfigBTN.ForeColor = System.Drawing.Color.White;
            this.SaveConfigBTN.Location = new System.Drawing.Point(476, 85);
            this.SaveConfigBTN.Name = "SaveConfigBTN";
            this.SaveConfigBTN.Size = new System.Drawing.Size(117, 26);
            this.SaveConfigBTN.TabIndex = 6;
            this.SaveConfigBTN.Text = "Save";
            this.SaveConfigBTN.Click += new System.EventHandler(this.SaveConfigBTN_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.SaveConfigBTN);
            this.Controls.Add(this.LoadConfigBTN);
            this.Controls.Add(this.ConfigListBoxCGF);
            this.Controls.Add(this.Switch3);
            this.Controls.Add(this.Switch2);
            this.Controls.Add(this.Switch1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2ToggleSwitch Switch1;
        private Guna.UI2.WinForms.Guna2ToggleSwitch Switch2;
        private Guna.UI2.WinForms.Guna2ToggleSwitch Switch3;
        private System.Windows.Forms.ListBox ConfigListBoxCGF;
        private Guna.UI2.WinForms.Guna2Button LoadConfigBTN;
        private Guna.UI2.WinForms.Guna2Button SaveConfigBTN;
    }
}

