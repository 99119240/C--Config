﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private Dictionary<string, Dictionary<string, bool>> allConfigs = new Dictionary<string, Dictionary<string, bool>>();
        private string selectedConfigKey;
        private readonly string configsFolderPath = "Configs";

        public Form1()
        {
            InitializeComponent();
            InitializeConfigsFolder();
        }

        private void ConfigListBoxCGF_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ConfigListBoxCGF.SelectedItem != null)
            {
                selectedConfigKey = ConfigListBoxCGF.SelectedItem.ToString();
            }
        }

        private void Switch3_CheckedChanged(object sender, EventArgs e)
        {
            UpdateSelectedConfig("Switch3", Switch3.Checked);
        }

        private void Switch2_CheckedChanged(object sender, EventArgs e)
        {
            UpdateSelectedConfig("Switch2", Switch2.Checked);
        }

        private void Switch1_CheckedChanged(object sender, EventArgs e)
        {
            UpdateSelectedConfig("Switch1", Switch1.Checked);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            InitializeDefaultConfigs();
            LoadConfig();
            UpdateListBox();
        }

        private void LoadConfigBTN_Click(object sender, EventArgs e)
        {
            LoadConfig();
        }

        private void SaveConfigBTN_Click(object sender, EventArgs e)
        {
            SaveConfig();
        }

        private void InitializeDefaultConfigs()
        {
            Dictionary<string, bool> defaultConfig1 = new Dictionary<string, bool>
            {
                {"Switch1", false },
                {"Switch2", false },
                {"Switch3", false }
            };

            Dictionary<string, bool> defaultConfig2 = new Dictionary<string, bool>
            {
                {"Switch1", false },
                {"Switch2", false },
                {"Switch3", false }
            };

            Dictionary<string, bool> defaultConfig3 = new Dictionary<string, bool>
            {
                {"Switch1", false },
                {"Switch2", false },
                {"Switch3", false }
            };

            allConfigs.Add("Config1", defaultConfig1);
            allConfigs.Add("Config2", defaultConfig2);
            allConfigs.Add("Config3", defaultConfig3);

            selectedConfigKey = "Config1";
        }

        private void LoadConfig()
        {
            try
            {
                if (selectedConfigKey != null && allConfigs.TryGetValue(selectedConfigKey, out Dictionary<string, bool> selectedConfig))
                {
                    string filePath = Path.Combine(configsFolderPath, $"{selectedConfigKey}.json");

                    if (File.Exists(filePath))
                    {
                        string json = File.ReadAllText(filePath);
                        selectedConfig = JsonConvert.DeserializeObject<Dictionary<string, bool>>(json);
                        allConfigs[selectedConfigKey] = selectedConfig;

                        Switch1.Checked = GetConfigValue("Switch1", selectedConfig);
                        Switch2.Checked = GetConfigValue("Switch2", selectedConfig);
                        Switch3.Checked = GetConfigValue("Switch3", selectedConfig);
                    }
                    else
                    {
                        // If the file doesn't exist, create a new one with default values
                        SaveConfig();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading configuration: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void SaveConfig()
        {
            try
            {
                if (selectedConfigKey != null && allConfigs.TryGetValue(selectedConfigKey, out Dictionary<string, bool> selectedConfig))
                {
                    selectedConfig["Switch1"] = Switch1.Checked;
                    selectedConfig["Switch2"] = Switch2.Checked;
                    selectedConfig["Switch3"] = Switch3.Checked;

                    string filePath = Path.Combine(configsFolderPath, $"{selectedConfigKey}.json");
                    string json = JsonConvert.SerializeObject(selectedConfig, Formatting.Indented);
                    File.WriteAllText(filePath, json);

                    MessageBox.Show("Configuration saved successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving configuration: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool GetConfigValue(string key, Dictionary<string, bool> config)
        {
            return config.TryGetValue(key, out bool value) ? value : false;
        }

        private void UpdateListBox()
        {
            ConfigListBoxCGF.Items.Clear();
            foreach (string key in allConfigs.Keys)
            {
                ConfigListBoxCGF.Items.Add(key);
            }
        }

        private void UpdateSelectedConfig(string key, bool value)
        {
            if (selectedConfigKey != null && allConfigs.TryGetValue(selectedConfigKey, out Dictionary<string, bool> selectedConfig))
            {
                selectedConfig[key] = value;
            }
        }

        private void InitializeConfigsFolder()
        {
            if (!Directory.Exists(configsFolderPath))
            {
                Directory.CreateDirectory(configsFolderPath);
            }
        }
    }
}
